﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Encryption
{
    public class CustomEncyptor
    {
        public string GenerateEncryptedValue(int valueToEncrypt, int sessionKey)
        {
            var checkSum = GetAllDigitsSum(valueToEncrypt);
            var checkSumNumbersCount = Math.Floor(Math.Log10(checkSum) + 1); //note: need to check if only one digit
            var encryptedValue = valueToEncrypt ^ sessionKey;
            var result = string.Format("{0}{1}{2}", checkSumNumbersCount, encryptedValue, checkSum);
            return result;
        }

        public int ExtractDeryptedValue(string valueToDecrypt, int sessionKey)
        {
            var checkSumNumbersCount = int.Parse(valueToDecrypt[0].ToString());
            var checkSum = Convert.ToInt32(valueToDecrypt.Substring(valueToDecrypt.Length - checkSumNumbersCount, checkSumNumbersCount));

            var value = Convert.ToInt32(valueToDecrypt.Substring(1, valueToDecrypt.Length - checkSumNumbersCount - 1));
            var result = value ^ sessionKey;

            var isChecksumEquals = checkSum == GetAllDigitsSum(result);
            return isChecksumEquals ?  result : - 100500;
        }

        private int GetAllDigitsSum(int value) 
        {
            var result = 0;
            while (value != 0)
            {
                result += value % 10;
                value /= 10;
            }

            return result;
        }
    }
}

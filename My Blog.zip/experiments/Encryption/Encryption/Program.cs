﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Encryption
{
    class Program
    {
        static void Main(string[] args)
        {
            var v = new CustomEncyptor();
            
            var value = v.GenerateEncryptedValue(10912, 10123123);
            Console.WriteLine(value);
            Console.WriteLine(v.ExtractDeryptedValue(value, 10123123));
            Console.WriteLine(v.ExtractDeryptedValue(value + "2", 1012312));`

            Console.WriteLine(v.GenerateEncryptedValue(1, 10));
            Console.WriteLine(v.GenerateEncryptedValue(12, 1123));
            Console.WriteLine(v.GenerateEncryptedValue(2099999999, 999999999));
            Console.WriteLine(v.GenerateEncryptedValue(1094512, 123123));
            Console.WriteLine(v.GenerateEncryptedValue(7810912, 3123));
            //var userId = 100;
            //var id = 900;
            //var sessionkey = 722125711;
            //var s = (userId ^ id) ^ sessionkey;
            
            //var s3 = Math.Floor(Math.Log10(sessionkey) + 1);
            //var data = (s3.ToString().Length == 1 ? "0" + s3 : s3.ToString()) + 2 + sessionkey.ToString() + s;

            //var d = (s ^ userId) ^ sessionkey;
            //var d2 = (s ^ userId) ^ 23;
            //var sd = Math.Abs(s.ToString().GetHashCode());
            //var dataToEncrypt = @"<u>525</u><i>1000</i>";
            //var s = new EncryptionService();
            //var result = s.EncryptToString(dataToEncrypt);

            //Console.WriteLine(@"originalData: {0}", dataToEncrypt);
            //Console.WriteLine(@"encrypted: {0} ", result);
            //Console.WriteLine(@"length: {0}", result.Length);

            //var resultAndCompressed = Convert.ToBase64String(EncryptAndCompressUtility.EncryptAndCompress(Encoding.Unicode.GetBytes(dataToEncrypt)));

            //Console.WriteLine(@"originalData: {0}", dataToEncrypt);
            //Console.WriteLine(@"encrypted: {0} ", resultAndCompressed);
            //Console.WriteLine(@"length: {0}", resultAndCompressed.Length);
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO.Compression;
using System.Security.Cryptography;
using System.IO;

namespace Encryption
{
public static class EncryptAndCompressUtility
{
    private static byte[] Key =
            {
                123, 217, 19, 11, 24, 26, 85, 45, 114, 184, 27, 162, 37, 112, 222, 209, 241, 24, 175, 144,
                173, 53, 196, 29, 24, 26, 17, 218, 131, 236, 53, 209
            };
    private static byte[] Vector = { 146, 64, 191, 111, 23, 3, 113, 119, 231, 121, 251, 112, 79, 32, 114, 156 };

     /// <summary>
     /// Encrypts and compresses the input. Returns the compressed and encrypted content and the key and iv vector used.
     /// </summary>
     /// <param name="input">The input array.</param>
     /// <param name="key">The key that has been used by the algorithm.</param>
     /// <param name="iv">The iv vector that has been used by the algorithm.</param>
     /// <returns></returns>
     public static byte[] EncryptAndCompress(byte[] input)
     {
         if (input == null)
             throw new ArgumentNullException("input");

        // Compress the input array into the given memory stream.
         MemoryStream stream = new MemoryStream();
         using (GZipStream zip = new GZipStream(stream, CompressionMode.Compress, true))
         {
             // Write the input to the memory stream via the ZIP stream.
             zip.Write(input, 0, input.Length);
         }

        // Create the keys and initalize the rijndael.
         RijndaelManaged r = new RijndaelManaged();
         r.Key = Key;
         r.IV = Vector;

        // Encrypt the compressed memory stream into the encrypted memory stream.
         MemoryStream encrypted = new MemoryStream();
         using (CryptoStream cryptor = new CryptoStream(encrypted, r.CreateEncryptor(), CryptoStreamMode.Write))
         {
             // Write the stream to the encrypted memory stream.
             cryptor.Write(stream.ToArray(), 0, (int)stream.Length);
             cryptor.FlushFinalBlock();
             // Return the result.
             return encrypted.ToArray();
         }
     }

    /// <summary>
     /// Decrypts and decompresses the input. Returns the decompressed and decrypted content.
     /// </summary>
     /// <param name="input">The input array.</param>
     /// <param name="key">The key used for decrypt.</param>
     /// <param name="iv">The iv vector used for decrypt.</param>
     /// <returns></returns>
     public static byte[] DecryptAndDecompress(byte[] input)
     {
         if (input == null)
             throw new ArgumentNullException("input");

        // Initialize the rijndael
         RijndaelManaged r = new RijndaelManaged();
         // Create the array that holds the result.
         byte[] decrypted = new byte[input.Length];
         // Create the crypto stream that is used for decrypt. The first argument holds the input as memory stream.
         using (CryptoStream decryptor = new CryptoStream(new MemoryStream(input), r.CreateDecryptor(Key, Vector), CryptoStreamMode.Read))
         {
             // Read the encrypted values into the decrypted stream. Decrypts the content.
             decryptor.Read(decrypted, 0, decrypted.Length);
         }

        // Create the zip stream to decompress.
         using(GZipStream zip = new GZipStream(new MemoryStream(decrypted), CompressionMode.Decompress, false))
         {
             // Read all bytes in the zip stream and return them.
             return ReadAllBytes(zip);
         }
     }

    /// <summary>
     /// Reads all bytes in the given zip stream and returns them.
     /// </summary>
     /// <param name="zip">The zip stream that is processed.</param>
     /// <returns></returns>
     private static byte[] ReadAllBytes(GZipStream zip)
     {
         if (zip == null)
             throw new ArgumentNullException("zip");

        int buffersize = 100;
         byte[] buffer = new byte[buffersize];
         int offset = 0, read = 0, size = 0;
         do
         {
             // If the buffer doesn’t offer enough space left create a new array
             // with the double size. Copy the current buffer content to that array
             // and use that as new buffer.
             if (buffer.Length < size + buffersize)
             {
                 byte[] tmp = new byte[buffer.Length * 2];
                 Array.Copy(buffer, tmp, buffer.Length);
                 buffer = tmp;
             }

            // Read the net chunk of data.
             read = zip.Read(buffer, offset, buffersize);

            // Increment offset and read size.
             offset += buffersize;
             size += read;
         } while (read == buffersize); // Terminate if we read less then the buffer size.

        // Copy only that amount of data to the result that has actually been read!
         byte[] result = new byte[size];
         Array.Copy(buffer, result, size);
         return result;
     }
}
}

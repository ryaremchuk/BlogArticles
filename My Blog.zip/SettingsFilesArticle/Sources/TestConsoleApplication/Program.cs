﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace TestConsoleApplication
{
public class Program
{
    public static void Main(string[] args)
    {
        Console.WriteLine("User: {0}" , CustomSettings.Default.UserName);
        //output: User: defualtUser

        CustomSettings.Default.UserName = "newUser";
        CustomSettings.Default.Save();
        Console.WriteLine("User: {0}" , CustomSettings.Default.UserName);
        //output: User: newUser
    }
}
}

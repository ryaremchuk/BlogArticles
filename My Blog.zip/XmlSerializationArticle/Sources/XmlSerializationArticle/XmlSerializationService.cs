﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Xml.Serialization;

namespace XmlSerializationArticle
{
    public static class XmlSerializationService
    {
        public static T Deserialize<T>(string serializedObject) where T : class
        {
            var serializer = new XmlSerializer(typeof(T));
            using (var sr = new StringReader(serializedObject))
            {
                return (T)serializer.Deserialize(sr);
            }
        }

        public static string Serialize<T>(T objectToSerialize) where T : class
        {
            var serializer = new XmlSerializer(typeof(T));

            using (var sw = new StringWriter())
            {
                serializer.Serialize(sw, objectToSerialize);
                return sw.ToString();
            }
        }
    }
}

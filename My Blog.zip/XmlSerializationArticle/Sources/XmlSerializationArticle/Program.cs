﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using XmlSerializationArticle.Entities;

namespace XmlSerializationArticle
{
    public class Program
    {
        public static void Main(string[] args)
        {
            var users = new List<User>
            {
                new User
                {
                    Name = "Rostyslav",
                    Age = 24,
                    Passwrod = "123",
                    EMail = "sample@email.com",
                    UserRole = Role.Administrator,
                },
                new User
                {
                    Name = "SomeAnotherGuy",
                    Age = 42,
                    Passwrod = "qwerty",
                    EMail = "sample2@email.com",
                    UserRole = Role.RegularUser,
                }
            };

            var xml = XmlSerializationService.Serialize(users);
            Console.WriteLine(xml);          
        }
    }
}
//var restoredUser = XmlSerializationService.Deserialize<Person>(xml);

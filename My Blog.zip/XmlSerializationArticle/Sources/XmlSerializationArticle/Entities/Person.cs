﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace XmlSerializationArticle.Entities
{
    public class Person: User
    {
        public string Address { get; set; }
    }
}

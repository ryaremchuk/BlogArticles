﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml.Serialization;

namespace XmlSerializationArticle.Entities
{
    public class User
    {
        [XmlAttribute]
        public string Name { get; set; }

        [XmlAttribute(AttributeName = "UserMail")]
        public string EMail { get; set; }

        [XmlAttribute]
        public string Passwrod { get; set; }

        [XmlIgnore]
        public int PasswordExpiresIn { get; set; }

        [XmlAttribute]
        public int Age { get; set; }

        [XmlAttribute]
        public Role UserRole { get; set; }
    }
}

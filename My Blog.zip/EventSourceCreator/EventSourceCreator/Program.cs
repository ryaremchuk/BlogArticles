﻿using System.Diagnostics;

namespace EventSourceCreator
{
    class Program
    {
        static void Main(string[] args)
        {
            const string sourceName = "EventSourceTest2333";
            const string targetLogName = "Application";

            EventSourceCreator.CreateSourceIfNotExists(sourceName, targetLogName);
        }
    }
}
